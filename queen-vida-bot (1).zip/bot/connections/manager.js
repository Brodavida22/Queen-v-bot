"use strict";

const fs = require("fs");
const path = require("path");
const baileys = require("@whiskeysockets/baileys");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  Browsers,
  makeCacheableSignalKeyStore,
} = baileys;

const pino = require("pino");
const config = require("../config");
const { logger } = require("../utils/logger");
const { sanitizeNumber } = require("../utils/format");
const { parseCommand, executeCommand } = require("../commands");

const sessions = new Map();
const pendingPairs = new Map();

function ensureSessionsDir() {
  if (!fs.existsSync(config.SESSIONS_DIR)) {
    fs.mkdirSync(config.SESSIONS_DIR, { recursive: true });
  }
}

function sessionPath(number) {
  return path.join(config.SESSIONS_DIR, sanitizeNumber(number));
}

async function handleMessages(sock, number, m) {
  try {
    const msg = m.messages && m.messages[0];
    if (!msg || !msg.message || msg.key.fromMe) return;

    const remoteJid = msg.key.remoteJid;
    if (!remoteJid) return;

    const messageContent =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      msg.message.imageMessage?.caption ||
      msg.message.videoMessage?.caption ||
      "";

    const parsed = parseCommand(messageContent);
    if (!parsed) return;

    const start = Date.now();
    const reply = await executeCommand(parsed.name, { start, sock, msg, number });

    if (reply) {
      await sock.sendMessage(remoteJid, { text: reply }, { quoted: msg });
      logger.info({ number, command: parsed.name, jid: remoteJid }, "Command handled");
    }
  } catch (err) {
    logger.error({ err: err?.message, number }, "Error handling message");
  }
}

async function createConnection(number, opts = {}) {
  const cleanNumber = sanitizeNumber(number);
  if (!cleanNumber) throw new Error("Invalid number");

  const existing = sessions.get(cleanNumber);
  if (existing && existing.sock?.user) {
    logger.info({ number: cleanNumber }, "Session already connected");
    return { sock: existing.sock, alreadyConnected: true };
  }

  ensureSessionsDir();
  const folder = sessionPath(cleanNumber);
  if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(folder);
  const { version } = await fetchLatestBaileysVersion();

  const silentLogger = pino({ level: "silent" });

  const sock = makeWASocket({
    version,
    logger: silentLogger,
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, silentLogger),
    },
    browser: Browsers.macOS("Desktop"),
    syncFullHistory: false,
    markOnlineOnConnect: false,
    generateHighQualityLinkPreview: true,
  });

  sessions.set(cleanNumber, { sock, number: cleanNumber, folder });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      logger.info({ number: cleanNumber }, "QR generated (pairing-code preferred)");
    }

    if (connection === "open") {
      logger.info({ number: cleanNumber, user: sock.user?.id }, "WhatsApp connected");
      pendingPairs.delete(cleanNumber);
    }

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const reason = Object.entries(DisconnectReason).find(
        ([, code]) => code === statusCode,
      )?.[0];
      logger.warn({ number: cleanNumber, statusCode, reason }, "Connection closed");

      sessions.delete(cleanNumber);

      if (statusCode === DisconnectReason.loggedOut) {
        try {
          fs.rmSync(folder, { recursive: true, force: true });
          logger.info({ number: cleanNumber }, "Session removed (logged out)");
        } catch (err) {
          logger.error({ err: err?.message }, "Failed to remove session folder");
        }
        return;
      }

      const shouldReconnect =
        statusCode !== DisconnectReason.loggedOut &&
        statusCode !== DisconnectReason.forbidden &&
        statusCode !== DisconnectReason.badSession;

      if (shouldReconnect) {
        const delay = 3000 + Math.floor(Math.random() * 2000);
        logger.info({ number: cleanNumber, delay }, "Reconnecting...");
        setTimeout(() => {
          createConnection(cleanNumber).catch((err) =>
            logger.error({ err: err?.message, number: cleanNumber }, "Reconnect failed"),
          );
        }, delay);
      }
    }
  });

  sock.ev.on("messages.upsert", (m) => handleMessages(sock, cleanNumber, m));

  return { sock, alreadyConnected: false };
}

async function requestPairingCode(number) {
  const cleanNumber = sanitizeNumber(number);
  if (!cleanNumber) throw new Error("Invalid number");

  if (pendingPairs.has(cleanNumber)) {
    return pendingPairs.get(cleanNumber);
  }

  const promise = (async () => {
    const { sock, alreadyConnected } = await createConnection(cleanNumber);

    if (alreadyConnected) {
      throw new Error("Number already connected");
    }

    if (sock.authState?.creds?.registered) {
      throw new Error("Session already registered. Restart bot to refresh.");
    }

    let attempts = 0;
    while (!sock.user && !sock.authState?.creds?.me && attempts < 5) {
      await new Promise((resolve) => setTimeout(resolve, 600));
      attempts++;
    }

    const code = await sock.requestPairingCode(cleanNumber);
    if (!code) throw new Error("Failed to generate pairing code");
    const formatted = code.match(/.{1,4}/g)?.join("-") || code;
    logger.info({ number: cleanNumber, code: formatted }, "Pairing code generated");
    return formatted;
  })();

  pendingPairs.set(cleanNumber, promise);

  promise.finally(() => {
    setTimeout(() => pendingPairs.delete(cleanNumber), 60_000);
  });

  return promise;
}

async function restoreAllSessions() {
  ensureSessionsDir();
  const entries = fs.readdirSync(config.SESSIONS_DIR, { withFileTypes: true });
  const directories = entries.filter((e) => e.isDirectory()).map((e) => e.name);

  if (!directories.length) {
    logger.info("No saved sessions to restore");
    return;
  }

  logger.info({ count: directories.length }, "Restoring saved sessions");

  for (const dir of directories) {
    const credsPath = path.join(config.SESSIONS_DIR, dir, "creds.json");
    if (!fs.existsSync(credsPath)) {
      logger.warn({ number: dir }, "Session has no creds, skipping");
      continue;
    }
    try {
      await createConnection(dir);
      logger.info({ number: dir }, "Session restored");
    } catch (err) {
      logger.error({ number: dir, err: err?.message }, "Failed to restore session");
    }
  }
}

function listSessions() {
  return Array.from(sessions.entries()).map(([number, s]) => ({
    number,
    connected: !!s.sock?.user,
    user: s.sock?.user?.id || null,
  }));
}

module.exports = {
  createConnection,
  requestPairingCode,
  restoreAllSessions,
  listSessions,
  sessions,
};
