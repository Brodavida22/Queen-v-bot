"use strict";

function sanitizeNumber(input) {
  if (input == null) return "";
  return String(input).replace(/[^0-9]/g, "");
}

function isValidNumber(num) {
  const cleaned = sanitizeNumber(num);
  return cleaned.length >= 8 && cleaned.length <= 15;
}

function formatUptime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (minutes) parts.push(`${minutes}m`);
  parts.push(`${seconds}s`);
  return parts.join(" ");
}

function formatDate(date = new Date()) {
  return date.toLocaleString("en-US", {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    timeZoneName: "short",
  });
}

module.exports = { sanitizeNumber, isValidNumber, formatUptime, formatDate };
