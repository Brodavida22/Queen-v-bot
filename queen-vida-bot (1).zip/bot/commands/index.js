"use strict";

const config = require("../config");
const { formatUptime, formatDate } = require("../utils/format");

function buildMenu() {
  const uptime = formatUptime(Date.now() - config.STARTED_AT);
  const date = formatDate();

  return (
    `╭━━━〔 👑 ${config.BOT_NAME} 👑 〕━━━╮\n` +
    `┃ 📅 LIVE DATE   : ${date}\n` +
    `┃ ⏱️ LIVE UPTIME : ${uptime}\n` +
    `┃ 📡 LIVE PING   : ${Date.now() % 1000} ms\n` +
    `┃ 🧬 VERSION     : ${config.VERSION}\n` +
    `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n` +
    `╭─〔 👥 GROUP 〕\n` +
    `│ • !tagall   • !kickall\n` +
    `│ • !promote  • !demote\n` +
    `│ • !mute     • !unmute\n` +
    `╰─────────────────\n\n` +
    `╭─〔 🛡️ SECURITY 〕\n` +
    `│ • !antilink • !antibot\n` +
    `│ • !antispam • !blocklist\n` +
    `╰─────────────────\n\n` +
    `╭─〔 🤖 AI 〕\n` +
    `│ • !ai       • !chat\n` +
    `│ • !img      • !translate\n` +
    `╰─────────────────\n\n` +
    `╭─〔 🛠️ TOOLS 〕\n` +
    `│ • !ping     • !alive\n` +
    `│ • !owner    • !menu\n` +
    `│ • !uptime   • !runtime\n` +
    `╰─────────────────\n\n` +
    `╭─〔 🎮 FUN 〕\n` +
    `│ • !joke     • !quote\n` +
    `│ • !meme     • !truth\n` +
    `╰─────────────────\n\n` +
    `╭───────────────╮\n` +
    `│  Use prefixes "!" or "."\n` +
    `╰───────────────╯`
  );
}

function buildAlive() {
  const uptime = formatUptime(Date.now() - config.STARTED_AT);
  return (
    `*✨ ${config.BOT_NAME} is Alive ✨*\n\n` +
    `╭─────────────────\n` +
    `│ 👑 Owner   : ${config.OWNER_NAME}\n` +
    `│ ⏱️ Uptime  : ${uptime}\n` +
    `│ 🧬 Version : ${config.VERSION}\n` +
    `│ 📡 Status  : Online\n` +
    `╰─────────────────\n\n` +
    `Type *!menu* to see all commands.`
  );
}

function buildOwner() {
  return (
    `*👑 BOT OWNER 👑*\n\n` +
    `Name   : ${config.OWNER_NAME}\n` +
    `Number : wa.me/${config.OWNER_NUMBER}\n` +
    `Bot    : ${config.BOT_NAME} ${config.VERSION}`
  );
}

const COMMANDS = {
  menu: () => buildMenu(),
  help: () => buildMenu(),
  alive: () => buildAlive(),
  owner: () => buildOwner(),
  ping: (start) => {
    const latency = Date.now() - start;
    return `🏓 Pong! _${latency} ms_`;
  },
  uptime: () => `⏱️ Uptime: ${formatUptime(Date.now() - config.STARTED_AT)}`,
  runtime: () => `⏱️ Runtime: ${formatUptime(Date.now() - config.STARTED_AT)}`,
};

function parseCommand(text) {
  if (!text || typeof text !== "string") return null;
  const trimmed = text.trim();
  if (!trimmed) return null;
  const prefix = config.PREFIXES.find((p) => trimmed.startsWith(p));
  if (!prefix) return null;
  const body = trimmed.slice(prefix.length).trim();
  if (!body) return null;
  const [name, ...args] = body.split(/\s+/);
  return { name: name.toLowerCase(), args, prefix };
}

async function executeCommand(name, ctx) {
  const handler = COMMANDS[name];
  if (!handler) return null;
  return handler(ctx.start);
}

module.exports = { parseCommand, executeCommand, COMMANDS };
