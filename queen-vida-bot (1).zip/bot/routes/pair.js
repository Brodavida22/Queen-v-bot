"use strict";

const express = require("express");
const { requestPairingCode } = require("../connections/manager");
const { isValidNumber, sanitizeNumber } = require("../utils/format");
const { logger } = require("../utils/logger");

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const rawNumber = req.body?.number;
    const number = sanitizeNumber(rawNumber);

    if (!isValidNumber(number)) {
      return res.status(400).json({
        error: "Invalid number. Provide international format e.g. 234801xxxxxxx",
      });
    }

    logger.info({ number }, "Pair request received");
    const code = await requestPairingCode(number);

    return res.json({ code });
  } catch (err) {
    logger.error({ err: err?.message }, "Pair request failed");
    return res.status(500).json({
      error: err?.message || "Failed to generate pairing code",
    });
  }
});

module.exports = router;
