"use strict";

const path = require("path");

const config = {
  PORT: parseInt(process.env.PORT || "3000", 10),

  ALLOWED_ORIGIN: "https://vida-queen-connect.lovable.app",

  BOT_NAME: "QUEEN VIDA BOT",
  VERSION: "v2.0.0",
  OWNER_NAME: process.env.OWNER_NAME || "Queen Vida",
  OWNER_NUMBER: process.env.OWNER_NUMBER || "234000000000",

  PREFIXES: ["!", "."],

  SESSIONS_DIR: path.resolve(__dirname, "sessions"),

  STARTED_AT: Date.now(),
};

module.exports = config;
