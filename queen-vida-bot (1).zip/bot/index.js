"use strict";

const express = require("express");
const cors = require("cors");

const config = require("./config");
const { logger } = require("./utils/logger");
const { restoreAllSessions, listSessions } = require("./connections/manager");
const pairRoute = require("./routes/pair");

process.on("uncaughtException", (err) => {
  logger.error({ err: err?.message, stack: err?.stack }, "Uncaught exception");
});

process.on("unhandledRejection", (reason) => {
  logger.error({ reason: reason?.message || reason }, "Unhandled rejection");
});

const app = express();

app.use(
  cors({
    origin: config.ALLOWED_ORIGIN,
    methods: ["GET", "POST", "OPTIONS"],
    credentials: false,
  }),
);

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));

app.get("/", (_req, res) => {
  res.json({
    name: config.BOT_NAME,
    version: config.VERSION,
    status: "online",
    uptimeMs: Date.now() - config.STARTED_AT,
    docs: { pair: "POST /pair { number: '234xxxxxxxx' }" },
  });
});

app.get("/healthz", (_req, res) => {
  res.json({ status: "ok", uptimeMs: Date.now() - config.STARTED_AT });
});

app.get("/sessions", (_req, res) => {
  res.json({ sessions: listSessions() });
});

app.use("/pair", pairRoute);

app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
});

app.use((err, _req, res, _next) => {
  logger.error({ err: err?.message }, "Express error");
  res.status(500).json({ error: err?.message || "Internal server error" });
});

const server = app.listen(config.PORT, "0.0.0.0", () => {
  logger.info(
    {
      port: config.PORT,
      bot: config.BOT_NAME,
      version: config.VERSION,
      cors: config.ALLOWED_ORIGIN,
    },
    `${config.BOT_NAME} ${config.VERSION} listening`,
  );

  restoreAllSessions().catch((err) =>
    logger.error({ err: err?.message }, "Session restore failed"),
  );
});

server.on("error", (err) => {
  logger.error({ err: err?.message }, "Server error");
});

module.exports = { app, server };
