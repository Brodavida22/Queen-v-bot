# Queen Vida WhatsApp Bot

Production-ready multi-user WhatsApp bot using Node.js + Baileys.

Designed to pair with the frontend at:
**https://vida-queen-connect.lovable.app/**

---

## Project Structure

```
bot/
 ├── index.js              # Express server entry point
 ├── config.js             # Bot config (port, prefixes, owner)
 ├── sessions/             # Per-user Baileys auth state
 ├── connections/
 │    └── manager.js       # Multi-user session manager
 ├── routes/
 │    └── pair.js          # POST /pair endpoint
 ├── commands/
 │    └── index.js         # !menu, !ping, !owner, !alive, ...
 └── utils/
      ├── logger.js
      └── format.js
```

---

## Run Locally

```bash
npm install
node bot/index.js
```

Server boots on `PORT` (default `3000`). All saved sessions in
`bot/sessions/` are restored automatically.

---

## API

### `GET /`

Returns bot status.

### `GET /healthz`

Returns `{ status: "ok" }`.

### `GET /sessions`

Returns currently connected sessions.

### `POST /pair`

Generates a WhatsApp pairing code for the supplied phone number.

Request:

```json
{ "number": "234801xxxxxxx" }
```

Response:

```json
{ "code": "ABCD-EFGH" }
```

CORS is restricted to `https://vida-queen-connect.lovable.app`.

---

## Bot Commands

Prefixes: `!` and `.`

- `menu` / `help` — full command menu
- `alive` — bot health
- `ping` — latency check
- `owner` — owner contact
- `uptime` / `runtime` — bot uptime

Commands run independently per session.

---

## VPS Deployment

### Plain Node

```bash
git clone <repo>
cd <repo>/artifacts/api-server
npm install
node bot/index.js
```

### PM2 (recommended)

```bash
npm install -g pm2
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
```

Then `pm2 logs queen-vida-bot` to follow logs and `pm2 restart queen-vida-bot`
to bounce the process.

---

## Environment Variables

| Var            | Default                  | Description                 |
| -------------- | ------------------------ | --------------------------- |
| `PORT`         | `3000`                   | HTTP port                   |
| `OWNER_NAME`   | `Queen Vida`             | Owner display name          |
| `OWNER_NUMBER` | `234000000000`           | Owner WhatsApp number       |
| `LOG_LEVEL`    | `info`                   | pino log level              |

---

## Stability

- Auto-reconnect on connection loss
- Per-number session folders (no cross-talk)
- Crash-safe (uncaught exceptions logged, not fatal)
- Stale pairing codes expire after 60s
- Sessions wiped automatically on `loggedOut`
